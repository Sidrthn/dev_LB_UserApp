// enum UserType {
//   user,
//   customer,
//   admin,
//   delivery_man,
//   vendor,
// }