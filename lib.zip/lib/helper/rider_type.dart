enum RiderType {
  initial,
  address,
  availableCar,
  cartNotFound,
  findRider,
  arrived,
  willArrived,
  ongoing,
  endTrip,
  rating,
}

enum CarType{
  luxury,
  standard,
}
